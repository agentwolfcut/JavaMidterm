package sit.int202.classicmodelstue;

public class TestEve {
    public static void main(String[] args) {
        int x= (int) ((Math.random()*5000)+1);
        System.out.println(x);
    }
}
